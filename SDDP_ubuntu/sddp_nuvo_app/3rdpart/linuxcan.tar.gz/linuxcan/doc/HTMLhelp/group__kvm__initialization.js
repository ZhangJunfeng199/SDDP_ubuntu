var group__kvm__initialization =
[
    [ "kvmGetErrorText", "group__kvm__initialization.html#ga87d29e88308410be0066473c9e975480", null ],
    [ "kvmGetVersion", "group__kvm__initialization.html#gaefbd601765b093d2e748c96191048a07", null ],
    [ "kvmInitialize", "group__kvm__initialization.html#ga59f41146c0cbea69a936edc1cdd6ebae", null ]
];