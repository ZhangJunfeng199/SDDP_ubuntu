var obsolete_8h =
[
    [ "canCHANNEL_CAP_CAN_DIAGNOSTICS", "obsolete_8h.html#a4867d2b7df8711010dd7f9441cbafa88", null ],
    [ "canCHANNEL_CAP_REMOTE", "obsolete_8h.html#a7748990724fd22b9be3cd02265358755", null ]
];