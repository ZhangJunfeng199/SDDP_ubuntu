var searchData=
[
  ['bool',['BOOL',['../linlib_8h.html#ac3247c51e4e3de674affb32998e133e2',1,'linlib.h']]],
  ['byte',['BYTE',['../linlib_8h.html#a4ae1dab0fb4b072a66584546209e7d58',1,'linlib.h']]]
];
