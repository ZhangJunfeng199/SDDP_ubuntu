var searchData=
[
  ['handle',['HANDLE',['../kvmlib_8h.html#aa8c0374618b33785ccb02f74bcfebc46',1,'kvmlib.h']]]
];
